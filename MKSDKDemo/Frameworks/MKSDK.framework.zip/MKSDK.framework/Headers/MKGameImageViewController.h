//
//  MKGameImageViewController.h
//  MKSDK
//
//  Created by 熙文 张 on 2017/9/11.
//  Copyright © 2017年 张熙文. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MKGameImageViewController : UIViewController


@end
